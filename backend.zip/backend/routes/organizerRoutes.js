const express = require("express");
const Organizer = require("../models/Organizer");

const router = express.Router();

// ✅ GET all organizers
router.get("/", async (req, res) => {
  try {
    const organizers = await Organizer.find();
    res.status(200).json(organizers);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

// ✅ POST (Add a new organizer)
router.post("/", async (req, res) => {
  try {
    if (req.body.photos) {
      req.body.images = req.body.photos;
      delete req.body.photos;
    }
    if (req.body.videos) {
      req.body.videos = req.body.videos;
    }

    const newOrganizer = new Organizer(req.body);
    const savedOrganizer = await newOrganizer.save();
    res.status(201).json(savedOrganizer);
  } catch (error) {
    res.status(400).json({ message: error.message });
  }
});

// ✅ PUT (Update an organizer)
router.put("/:id", async (req, res) => {
  try {
    const updates = { ...req.body };

    if (req.body.photos) {
      updates.images = req.body.photos;
      delete updates.photos;
    }
    if (req.body.videos) {
      updates.videos = req.body.videos;
    }

    const updatedOrganizer = await Organizer.findByIdAndUpdate(
      req.params.id,
      updates,
      { new: true, runValidators: true }
    );

    if (!updatedOrganizer) {
      return res.status(404).json({ message: "Organizer not found" });
    }

    res.status(200).json(updatedOrganizer);
  } catch (error) {
    res.status(400).json({ message: error.message });
  }
});

// ✅ DELETE a single organizer by ID
router.delete("/:id", async (req, res) => {
  try {
    const deletedOrganizer = await Organizer.findByIdAndDelete(req.params.id);
    if (!deletedOrganizer) {
      return res.status(404).json({ message: "Organizer not found" });
    }
    res.status(200).json({ message: "Organizer deleted successfully" });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

// ✅ DELETE all organizers
router.delete("/", async (req, res) => {
  try {
    await Organizer.deleteMany({});
    res.status(200).json({ message: "All organizers deleted successfully" });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

module.exports = router;
