const express = require("express");
const Booking = require("../models/Booking");
const router = express.Router();

// Debug Middleware: Log every request
router.use((req, res, next) => {
  console.log(`📩 ${req.method} request to ${req.originalUrl}`);
  next();
});

// 📌 POST: Create a new booking
router.post("/book", async (req, res) => {
  try {
    console.log("Incoming Request Data:", req.body); // ✅ Debugging

    const { name, email, date } = req.body;
    if (!name || !email || !date) {
      return res.status(400).json({ message: "All fields are required!" });
    }

    const newBooking = new Booking({ name, email, date });
    await newBooking.save();

    console.log("✅ Booking saved:", newBooking); // ✅ Log success
    res.status(201).json({ message: "Booking successful", booking: newBooking });
  } catch (error) {
    console.error("❌ Error saving booking:", error); // ✅ Log errors
    res.status(500).json({ message: "Server error", error: error.message });
  }
});

// 📌 GET: Fetch all bookings
router.get("/bookings", async (req, res) => {
  try {
    console.log("Fetching all bookings...");
    const bookings = await Booking.find();
    res.status(200).json(bookings);
  } catch (error) {
    console.error("❌ Error fetching bookings:", error);
    res.status(500).json({ message: "Server error", error: error.message });
  }
});

module.exports = router;
