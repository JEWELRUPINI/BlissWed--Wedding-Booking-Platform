const express = require("express");
const mongoose = require("mongoose");
const cors = require("cors");
require("dotenv").config();

const app = express();
const PORT = process.env.PORT || 5000;

// Middleware
app.use(express.json()); // ✅ Allows parsing of JSON requests
app.use(cors()); // ✅ Enables cross-origin requests

// MongoDB connection
const mongoURI =
  "mongodb+srv://jewel:8131844117@cluster0.bdsz0.mongodb.net/weddingDB?retryWrites=true&w=majority";

mongoose
  .connect(mongoURI)
  .then(() => console.log("✅ MongoDB Connected Successfully!"))
  .catch((err) => console.error("❌ MongoDB Connection Failed:", err));

// Import Routes
const bookingRoutes = require("./routes/bookingRoutes"); // ✅ Existing Booking API
const organizerRoutes = require("./routes/organizerRoutes"); // ✅ New Organizer API

// Use Routes
app.use("/api/bookings", bookingRoutes); // ✅ "/api/bookings" for Wedding Bookings
app.use("/api/organizers", organizerRoutes); // ✅ "/api/organizers" for Event Organizers

// Test Route (Optional)
app.get("/", (req, res) => {
  res.send("✅ API is working!");
});

// Start the server
app.listen(PORT, () => {
  console.log(`🚀 Server running on port ${PORT}`);
});
