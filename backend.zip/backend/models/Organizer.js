const mongoose = require("mongoose");

const organizerSchema = new mongoose.Schema({
  name: { type: String, required: true },
  services: [{ type: String, enum: ["Decoration", "Photography", "Catering"] }],
  images: [String], // Stores event photos
  videos: [String], // Stores video URLs
  contact: {
    phone: { type: String, required: true },
    email: { type: String, required: true },
  },
  eventManagers: [
    {
      name: { type: String, required: true },
      decoration: String, // Description or image URL
      image: String, // Profile photo
    }
  ],
  extraFeatures: {
    choirGroup: { name: String, image: String },
    cateringGroups: [{ name: String, image: String }],
    photographers: [{ name: String, image: String }],
    makeupArtists: [{ name: String, image: String }]
  }
});

const Organizer = mongoose.model("Organizer", organizerSchema);
module.exports = Organizer;
