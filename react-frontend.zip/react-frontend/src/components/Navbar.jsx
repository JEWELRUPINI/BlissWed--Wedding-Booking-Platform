import React from "react";
import { Link, useLocation } from "react-router-dom";

const Navbar = () => {
  const location = useLocation(); // To highlight active links

  return (
    <div className="navbar">
      <Link
        to="/"
        className={location.pathname === "/" ? "active" : ""}
      >
        Home
      </Link>
      <Link
        to="/organizers"
        className={location.pathname === "/organizers" ? "active" : ""}
      >
        Organizers
      </Link>
      <Link
        to="/bookings"
        className={location.pathname === "/bookings" ? "active" : ""}
      >
        Bookings
      </Link>
    </div>
  );
};

export default Navbar;
