import React, { useState } from "react";
import { useLocation } from "react-router-dom";
import axios from "axios";

const Bookings = () => {
  const location = useLocation();
  const queryParams = new URLSearchParams(location.search);
  const organizerName = queryParams.get("organizer") || "";

  const [formData, setFormData] = useState({
    name: "",
    email: "",
    date: "",
    organizer: organizerName, // Auto-filled if coming from Organizers page
  });

  const [message, setMessage] = useState("");

  const handleChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      const response = await axios.post("http://localhost:5000/api/bookings/book", formData);
      setMessage(response.data.message);
      setFormData({ name: "", email: "", date: "", organizer: organizerName });
    } catch (error) {
      console.error("Error submitting booking:", error);
      setMessage("Booking failed. Please try again.");
    }
  };

  return (
    <div>
      <h1 className="text-2xl font-bold mb-4">Book an Organizer</h1>
      {message && <p className="text-green-600">{message}</p>}

      <form onSubmit={handleSubmit} className="max-w-md p-4 border rounded-md shadow-md">
        <label className="block mb-2">Full Name:</label>
        <input
          type="text"
          name="name"
          value={formData.name}
          onChange={handleChange}
          required
          className="w-full border px-2 py-1 rounded-md"
        />

        <label className="block mt-3 mb-2">Email:</label>
        <input
          type="email"
          name="email"
          value={formData.email}
          onChange={handleChange}
          required
          className="w-full border px-2 py-1 rounded-md"
        />

        <label className="block mt-3 mb-2">Date:</label>
        <input
          type="date"
          name="date"
          value={formData.date}
          onChange={handleChange}
          required
          className="w-full border px-2 py-1 rounded-md"
        />

        <label className="block mt-3 mb-2">Organizer:</label>
        <input
          type="text"
          name="organizer"
          value={formData.organizer}
          onChange={handleChange}
          required
          className="w-full border px-2 py-1 rounded-md"
          readOnly
        />

        <button type="submit" className="mt-4 bg-green-600 text-white py-2 px-4 rounded-md hover:bg-green-700">
          Confirm Booking
        </button>
      </form>
    </div>
  );
};

export default Bookings;
