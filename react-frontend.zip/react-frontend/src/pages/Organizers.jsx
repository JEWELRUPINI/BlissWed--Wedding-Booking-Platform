import React, { useEffect, useState } from "react";
import axios from "axios";
import { useNavigate } from "react-router-dom";

const Organizers = () => {
  const [organizers, setOrganizers] = useState([]);
  const [editingOrganizer, setEditingOrganizer] = useState(null);
  const [formData, setFormData] = useState({ 
    name: "", 
    contact: { phone: "", email: "" },
    photos: [], 
    videos: [] 
  });

  const API_URL = "http://localhost:5000/api/organizers";
  const navigate = useNavigate();

  useEffect(() => {
    const fetchOrganizers = async () => {
      try {
        const response = await axios.get(API_URL);
        setOrganizers(response.data);
      } catch (error) {
        console.error("Error fetching organizers:", error);
      }
    };
    fetchOrganizers();
  }, []);

  // 🔹 Open edit form with organizer details
  const handleEditClick = (organizer) => {
    setEditingOrganizer(organizer._id);
    setFormData({ 
      name: organizer.name, 
      contact: { ...organizer.contact },
      photos: organizer.images || [], 
      videos: organizer.videos || []
    });
  };

  const handleDelete = async (id) => {
    try {
      await axios.delete(`${API_URL}/${id}`);
      setOrganizers(organizers.filter(org => org._id !== id));
    } catch (error) {
      console.error("Error deleting organizer:", error);
    }
  };

  const handleChange = (e) => {
    const { name, value } = e.target;
    if (name.includes("contact.")) {
      setFormData((prev) => ({
        ...prev,
        contact: { ...prev.contact, [name.split(".")[1]]: value },
      }));
    } else {
      setFormData((prev) => ({ ...prev, [name]: value }));
    }
  };

  const handlePhotoChange = (e, index) => {
    const updatedPhotos = [...formData.photos];
    updatedPhotos[index] = e.target.value;
    setFormData((prev) => ({ ...prev, photos: updatedPhotos }));
  };

  const handleVideoChange = (e, index) => {
    const updatedVideos = [...formData.videos];
    updatedVideos[index] = e.target.value;
    setFormData((prev) => ({ ...prev, videos: updatedVideos }));
  };

  const addPhotoField = () => setFormData((prev) => ({ ...prev, photos: [...prev.photos, ""] }));
  const addVideoField = () => setFormData((prev) => ({ ...prev, videos: [...prev.videos, ""] }));

  // 🔹 Handle form submission (update organizer)
  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      await axios.put(`${API_URL}/${editingOrganizer}`, formData);
      setOrganizers((prev) =>
        prev.map((org) => (org._id === editingOrganizer ? { ...org, ...formData } : org))
      );
      setEditingOrganizer(null); // Close the edit form after saving
    } catch (error) {
      console.error("Error updating organizer:", error);
    }
  };

  return (
    <div className="content-box">
      <h1>Wedding Organizers</h1>

      {organizers.map((organizer) => (
        <div key={organizer._id} className="organizer-details">
          {editingOrganizer === organizer._id ? (
            <form onSubmit={handleSubmit}>
              <input
                type="text"
                name="name"
                value={formData.name}
                onChange={handleChange}
              />
              <input
                type="text"
                name="contact.phone"
                value={formData.contact.phone}
                onChange={handleChange}
                placeholder="Phone"
              />
              <input
                type="email"
                name="contact.email"
                value={formData.contact.email}
                onChange={handleChange}
                placeholder="Email"
              />

              {/* Photos Input */}
              <div>
                <h4>Photo Links (Google Drive)</h4>
                {formData.photos.map((photo, index) => (
                  <input
                    key={index}
                    type="text"
                    value={photo}
                    onChange={(e) => handlePhotoChange(e, index)}
                    placeholder="Google Drive Image URL"
                  />
                ))}
                <button type="button" onClick={addPhotoField}>+ Add Photo</button>
              </div>

              {/* Videos Input */}
              <div>
                <h4>Video Links (YouTube)</h4>
                {formData.videos.map((video, index) => (
                  <input
                    key={index}
                    type="text"
                    value={video}
                    onChange={(e) => handleVideoChange(e, index)}
                    placeholder="YouTube Video URL"
                  />
                ))}
                <button type="button" onClick={addVideoField}>+ Add Video</button>
              </div>

              <button type="submit">Save</button>
              <button type="button" onClick={() => setEditingOrganizer(null)}>Cancel</button>
            </form>
          ) : (
            <>
              <h2>{organizer.name}</h2>
              <p><strong>Services:</strong> {organizer.services.join(", ")}</p>
              <p>📞 {organizer.contact?.phone || "N/A"} | ✉️ {organizer.contact?.email || "N/A"}</p>

              {/* View Photos Button */}
              {organizer.images?.length > 0 && (
                <button onClick={() => organizer.images.forEach(photo => window.open(photo, "_blank"))}>View Photos</button>
              )}

              {/* View Videos Button */}
              {organizer.videos?.length > 0 && (
                <button onClick={() => organizer.videos.forEach(video => window.open(video, "_blank"))}>View Videos</button>
              )}

              <button onClick={() => handleEditClick(organizer)}>Edit</button>
              <button onClick={() => handleDelete(organizer._id)}>Delete</button>
            </>
          )}
        </div>
      ))}
    </div>
  );
};

export default Organizers;
