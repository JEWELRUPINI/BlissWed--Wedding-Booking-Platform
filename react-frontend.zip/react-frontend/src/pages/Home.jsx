import React from "react";

const Home = () => {
  return <h1 className="text-2xl font-bold">Welcome to the Wedding Booking App 🎉</h1>;
};

export default Home;
