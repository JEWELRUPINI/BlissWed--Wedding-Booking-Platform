import React from "react";
import { Routes, Route } from "react-router-dom";
import Navbar from "./components/Navbar";
import Home from "./pages/Home";
import Organizers from "./pages/Organizers";
import Bookings from "./pages/Bookings";

const App = () => {
  return (
    <div className="container mx-auto p-4">
      {/* Navbar will be positioned in the top-right corner */}
      <Navbar />
      
      {/* Define Routes for Home, Organizers, and Bookings pages */}
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/organizers" element={<Organizers />} />
        <Route path="/bookings" element={<Bookings />} />
      </Routes>
    </div>
  );
};

export default App;


